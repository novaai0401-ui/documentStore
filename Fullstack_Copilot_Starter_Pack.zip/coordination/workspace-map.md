# Workspace map

Paths below are relative to the parent folder opened in VS Code. Replace UNSET
or ask Fullstack to discover a unique candidate and show it for confirmation.
Keep repository-specific instructions inside their existing repositories.

| Item | Value |
| --- | --- |
| React repository root | UNSET |
| React app directory within that root | UNSET |
| Spring repository root | UNSET |
| Spring module directory within that root | UNSET |
| Team base branch for React | UNSET |
| Team base branch for Spring | UNSET |
| Authoritative API contract path and owner | UNSET |
| React runtime and package manager from repo | UNSET |
| Spring Java and build tool from repo | UNSET |
| React dependency setup command and working directory | UNSET |
| React non-watch tests and working directory | UNSET |
| React lint/typecheck/build and working directory | UNSET |
| Spring test/build and working directory | UNSET |
| Frontend and backend start commands and directories | UNSET |
| Local frontend URL and backend base URL/profile | UNSET |
| Required local services and approved setup document | UNSET |

Populate only supported facts. Keep missing facts UNSET with an owner/question.
Do not put passwords, tokens or private connection strings in this file.
If no formal API contract exists, current-task.md holds the accepted task-specific
contract; mark it DRAFT until the required behavior is confirmed.
