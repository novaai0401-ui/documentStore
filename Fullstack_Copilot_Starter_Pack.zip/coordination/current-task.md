# Current task

## Request
Task ID: UNSET
Goal: UNSET
Acceptance criteria: UNSET
Scope and exclusions: UNSET

## Agreed API behavior
Contract source and revision: UNSET
Decision status: DRAFT
Route and method: UNSET
Request fields and validation: UNSET
Response fields and null behavior: UNSET
Status codes and error shape: UNSET
Compatibility or deployment order: UNSET
Decisions and unresolved questions: UNSET

## Latest shared snapshot
Snapshot ID: UNSET
React root, branch and HEAD: UNSET
Spring root, branch and HEAD: UNSET
Relevant staged, unstaged and untracked files: UNSET
Contract content/version checked: UNSET
Delegation observed: parallel / serial / unverified
Both helper results match this snapshot: NOT CHECKED

## Plan and results
Accepted plan: UNSET
Changed files by repository: UNSET
Checks and evidence: UNSET
Integration result: NOT RUN
Remaining blockers: UNSET
Next action: UNSET
React commit or PR: UNSET
Spring commit or PR: UNSET

Use a new snapshot ID whenever relevant inputs change. Keep this file concise.
Before starting another ticket, save a copy under coordination/history/<task-id>.md
and reset this file. Updating this local file does not publish it to either repo.
