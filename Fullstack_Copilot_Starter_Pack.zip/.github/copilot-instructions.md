# Shared workspace instructions

This workspace contains two independent repositories. Use Fullstack for work
that needs their combined context. Read coordination/workspace-map.md to resolve
their actual paths; do not guess them from these templates. Read each repository's
own applicable instructions before working there. Keep Git commands scoped to
one verified root. Keep one task and one contract revision across both checks.
Use existing company development, review and security controls. Report evidence,
test failures and unverified work plainly. Do not claim automatic synchronization
or guaranteed token savings. The supplied helpers only read and search.
