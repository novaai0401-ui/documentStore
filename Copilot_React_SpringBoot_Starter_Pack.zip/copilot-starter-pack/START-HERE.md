# GitHub Copilot starter pack

Companion to GitHub Copilot Organization Handbook. Prepared 4 October 2026 for separate React and Java Spring Boot repositories using Copilot Business or Enterprise.

## Install
1. Unzip into a temporary folder. Open your React repository root in VS Code and create a working branch.
2. Merge the contents of react-repo into that repository. For Spring Boot, merge springboot-repo into its own repository. Copy the contents, not the enclosing example folder. Preserve existing .github files; reconcile instructions instead of overwriting them.
3. Ask the implementation agent to draft docs/copilot/project-profile.md from manifests, CI and examples, citing file evidence and marking unknowns. The repository owner confirms facts and commands and adds existing policy references to company-rules.md. No company policies or commands have been assumed by these templates.
4. Select the intended Copilot session in VS Code. Use Chat: Open Customizations or the Configure Chat menu to inspect agents, instructions and skills. Confirm the three agents load and only their intended tools are available. Unknown tool names may be ignored; use the installed version's tool picker to resolve missing tools.
5. Check the React applyTo patterns against actual source paths; narrow them if the repository also includes unrelated JavaScript. Spring instructions target Java files; the Spring implementation agent also explicitly references them.
6. Run a harmless pilot on a branch. Confirm the planner and reviewer cannot edit or execute, the implementation agent can run an approved local test, and matching stack instructions are loaded.
7. Select the implementation agent and type /verify-change, /diagnose-issue or /api-contract-check as appropriate. If the slash command is unavailable, attach the SKILL.md and paste its task instructions into chat with the same agent. A skill does not grant tools.
8. Submit these customizations through the normal PR process. Record the tested VS Code version, Copilot client version, session target and owner. This pack has been structurally checked, not executed against your company projects.

## Everyday use
Select task-planner for unfamiliar or multi-file work. Fill in task-brief.md or paste its fields into chat and attach relevant files. Accept or correct the plan. Select react-implementer or spring-implementer to make the change. Run /verify-change and use change-reviewer with the diff and test output. Complete normal human review and CI before merge.

## Separate repository rule
Use a shared contract pinned to a commit, tag or published version. Attach an approved snapshot when the paired repo is not accessible. Keep a linked task or PR for each repo; do not assume either session sees the other repository.

## Compatibility and maintenance
Custom agents use .agent.md files; skills use SKILL.md. Legacy .prompt.md files are deliberately omitted because current Agent Host sessions do not load them. Local sessions still support them for now. The templates use documented tool aliases and do not pin a model. Benchmark approved models in your organization before selecting one. No external MCP server or automatic subagent chain is required.

Keep ordinary task wording concise, investigate before retrying, and measure credits per accepted change. Do not remove tests to reduce usage. Prompts do not enforce access restrictions: retain managed permissions, required CI and human review.
