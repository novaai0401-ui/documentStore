# Pilot acceptance checklist

- [ ] Both repositories load their own instructions and three custom agents.
- [ ] All project profile placeholders are completed or explicitly marked not applicable.
- [ ] Company policy references have an owner and review date.
- [ ] Read-only agents expose read and search only; verify tool availability in the installed client.
- [ ] Implementation agents expose read, search, edit and execute only, subject to approval controls.
- [ ] A sample matching file attaches the correct stack instructions in diagnostics or response references.
- [ ] All three skills are discoverable and run with the selected agent's existing permissions.
- [ ] Local lint, tests and build commands are verified by a maintainer.
- [ ] Synthetic test data and development-only credentials are used.
- [ ] React and Spring tasks use the same immutable API contract revision.
- [ ] A deliberately failing acceptance case is detected by tests or review.
- [ ] A missing required check is reported as not run, never as passed.
- [ ] Baseline and configured trials record actual credits, completion time and reviewer corrections.
- [ ] Normal CI, required reviewers and release controls remain in force.
