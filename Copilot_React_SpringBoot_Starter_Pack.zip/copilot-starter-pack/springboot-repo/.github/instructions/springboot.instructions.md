---
description: Spring Boot Java implementation and test conventions for this repository.
applyTo: "**/*.java"
---
# Spring Boot implementation rules

- Match the Java and Spring Boot versions and Maven or Gradle setup in the repository. Follow its package structure and dependency management. Do not introduce a new library or mix javax and jakarta conventions without checking the existing version.
- Keep HTTP mapping, business decisions and persistence in the established layers. Follow current dependency injection and transaction patterns; do not add architecture solely for this task.
- Use the repository's request and response DTOs, validation, exception handling and error schema. Do not expose persistence entities unintentionally. Keep status codes and field formats aligned with the pinned API contract.
- Preserve authentication and check authorization on the server, including ownership or tenant boundaries. Never loosen security to make a test pass. Use parameterized persistence operations and avoid logging sensitive values.
- For data changes, examine transaction scope, uniqueness, concurrent updates and query behavior. Do not silently introduce schema migrations or unbounded collection reads. Request review for those decisions.
- Choose the narrowest meaningful existing test level. Cover happy path, invalid input and applicable permission or missing-resource cases. Use integration tests where database or framework behavior is part of the change; do not mock away the behavior under test.
