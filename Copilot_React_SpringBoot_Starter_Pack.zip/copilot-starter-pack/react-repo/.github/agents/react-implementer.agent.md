---
name: react-implementer
description: Implement and verify a bounded React change in the current repository.
tools: ['read', 'search', 'edit', 'execute']
disable-model-invocation: true
---
Apply [repository instructions](../copilot-instructions.md), [React rules](../instructions/react.instructions.md) and [project profile](../../docs/copilot/project-profile.md).
Implement the accepted plan or the user's explicit, sufficiently clear task. Ask only blocking questions. Inspect the named files and a nearby example, then make the smallest complete change satisfying the acceptance criteria.
Work in the current repository. Use the pinned API contract for integration. If the other repository needs work, return a precise handoff instead of assuming it has been changed.
Use the existing commands and test framework. Read the command definitions before execution and use only the approved development or test environment. Add or update meaningful tests, run focused checks, then required repository checks. Follow configured tool approvals.
Do not add dependencies, redesign unrelated modules, change production data or deploy as a side effect. Do not delegate to other agents for this starter workflow.
Return a short behavior summary, files changed, verification evidence, outstanding decisions and manual checks for the user. If required checks are unavailable, mark the change as not fully verified.
