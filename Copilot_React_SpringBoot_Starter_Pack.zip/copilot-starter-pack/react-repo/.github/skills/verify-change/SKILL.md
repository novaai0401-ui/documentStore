---
name: verify-change
description: Verify a completed change against its acceptance criteria and required repository checks.
disable-model-invocation: true
---
# Verify change

Use the repository instructions and [project profile](../../../docs/copilot/project-profile.md). This skill does not expand the selected agent's tools or permissions.

Read the task brief, changed files, project profile and relevant test configuration. Map each acceptance criterion to an existing or needed check. With an implementation agent that has execution tools, run the approved focused checks and then required checks. Do not install tools or change files as part of this verification unless separately requested. With a read-only agent, inspect supplied evidence and report that checks were not executed.
Return a compact table: acceptance criterion, check performed, actual result and gap. Distinguish passed, failed and not run. Report failures without suppressing or rewriting assertions. Name any remaining manual checks and do not call the task complete when a required check is missing.
