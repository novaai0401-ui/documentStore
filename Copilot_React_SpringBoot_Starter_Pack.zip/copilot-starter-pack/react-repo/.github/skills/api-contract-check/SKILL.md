---
name: api-contract-check
description: Compare a change with the pinned API contract across separate React and Spring Boot repositories.
disable-model-invocation: true
---
# Api contract check

Use the repository instructions and [project profile](../../../docs/copilot/project-profile.md). This skill does not expand the selected agent's tools or permissions.

Read the contract location and immutable revision from the project profile. If inaccessible, request an approved local snapshot or attachment; do not infer an API from a UI mockup. Read only the operations touched by the task.
Compare method and path, parameters, required fields, types, nullability, enum values, dates, status codes, error schema, auth rules and pagination. Identify which repository owns each needed correction. State which repositories were actually inspected.
Return mismatches with file evidence, compatibility concerns, required contract or integration tests and a concise handoff for the other repository. Do not edit the contract, generated clients or the other repository unless that change is explicitly in scope.
