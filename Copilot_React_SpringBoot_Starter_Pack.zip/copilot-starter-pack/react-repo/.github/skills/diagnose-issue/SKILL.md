---
name: diagnose-issue
description: Diagnose a reproducible React or Spring Boot failure from evidence before attempting a fix.
disable-model-invocation: true
---
# Diagnose issue

Use the repository instructions and [project profile](../../../docs/copilot/project-profile.md). This skill does not expand the selected agent's tools or permissions.

Collect expected behavior, observed behavior, exact reproduction, sanitized error and relevant versions. Read the nearby code and failing test. Rank a small number of plausible causes and choose one diagnostic check that distinguishes them. Use approved local commands only when the selected agent has execution tools.
Confirm a cause with evidence before editing. A request to diagnose authorizes investigation only; a request to fix also authorizes a focused correction. After two unsuccessful correction attempts, stop, summarize what was ruled out and request the missing evidence or specialist help. Return cause or leading hypothesis, evidence, proposed smallest fix and regression check.
