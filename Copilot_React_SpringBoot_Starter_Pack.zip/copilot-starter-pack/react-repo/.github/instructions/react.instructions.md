---
description: React source and UI test conventions for this repository.
applyTo: "**/*.tsx,**/*.jsx,**/*.ts,**/*.js,**/*.css,**/*.scss"
---
# React implementation rules

- Follow the repository's React version and JavaScript or TypeScript choice. Reuse its component library, router, form, state and API client patterns. Do not introduce a new state or styling library for a small feature.
- Keep rendering separate from data access where the existing design does so. Use the established data fetching and cancellation strategy; handle stale responses when requests overlap.
- Define loading, empty, success, failure and disabled states as relevant. Preserve keyboard operation, meaningful labels, focus behavior and accessible error messages.
- Match the pinned API contract for request and response fields, nullability, dates, errors and pagination. Reuse generated types if this repository uses them; do not edit generated clients directly.
- Treat client-side validation as user assistance. Authorization and trusted validation remain server responsibilities. Do not place secrets in frontend code or change token storage without review.
- Test observable user behavior using the existing test framework. Include a failure case and the acceptance criteria. Avoid snapshots as the only evidence and avoid speculative memoization.
