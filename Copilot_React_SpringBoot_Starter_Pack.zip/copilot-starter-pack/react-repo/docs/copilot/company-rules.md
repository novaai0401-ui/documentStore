# Company rules

Complete with approved, non-sensitive policy references. This template does not establish company policy. Apply the organization's existing policies while these fields are being completed.

- Policy owner and review date: [TEAM TO COMPLETE]
- Allowed source code and data classifications: [TEAM TO COMPLETE]
- Approved Copilot account, models and session types: [TEAM TO COMPLETE]
- Approved extensions, MCP servers and network destinations: [TEAM TO COMPLETE]
- Secrets and customer-data handling requirements: [TEAM TO COMPLETE]
- Dependency approval and licensing rules: [TEAM TO COMPLETE]
- Required security, quality and accessibility checks: [TEAM TO COMPLETE]
- Pull request, human review and release rules: [TEAM TO COMPLETE]
- Incident reporting and escalation contact: [TEAM TO COMPLETE]

Do not put credentials, secrets or confidential policy contents in this file. Link to an approved source and state relevant permitted actions. Instructions guide AI behavior; access controls, CI and review enforce requirements.
