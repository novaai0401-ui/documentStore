# Task brief

- Outcome and user affected:
- Current behavior and reproduction steps:
- Expected behavior:
- In scope files or feature area:
- Out of scope:
- Relevant example, sanitized error or screenshot:
- API contract version and operations:
- Acceptance criteria with observable pass results:
- Required tests and approved commands:
- Known constraints or dependencies:

## Completion evidence
- Changed behavior and files:
- Checks run with results:
- Checks not run with reasons:
- Manual verification:
- Open risks and decisions:
- Paired repository PR and contract revision if applicable:
