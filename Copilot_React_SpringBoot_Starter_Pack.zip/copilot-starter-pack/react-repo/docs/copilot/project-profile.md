# React project profile

The repository owner completes this file with verified facts before rollout. Bracketed values are placeholders, not instructions or runnable commands. Reference manifests and CI configuration for evidence; update this file when they change.

## Ownership
- Repository and technical owner: [TEAM TO COMPLETE]
- Paired repository and owner: [TEAM TO COMPLETE]
- Product purpose and relevant domain glossary: [TEAM TO COMPLETE]
- Reviewed on and customization version: [TEAM TO COMPLETE]

## Frontend facts
- Source and test roots: [TEAM TO COMPLETE]
- React version and JavaScript or TypeScript: [TEAM TO COMPLETE]
- Node version and package manager from lockfile: [TEAM TO COMPLETE]
- Routing, state, forms and styling choices: [TEAM TO COMPLETE]
- Shared components and example component with tests: [TEAM TO COMPLETE]
- API client and generated client policy: [TEAM TO COMPLETE]

## Approved local commands
For each command record working directory, exact command for the team's operating system, prerequisites, expected pass result and CI equivalent. Do not invent script names. Mark non-applicable rows with a reason.
- Install using the lockfile or wrapper: [TEAM TO COMPLETE]
- Run locally with synthetic data: [TEAM TO COMPLETE]
- Focused test and example target: [TEAM TO COMPLETE]
- Lint and formatting check: [TEAM TO COMPLETE]
- Type check or compile: [TEAM TO COMPLETE]
- Required full test suite: [TEAM TO COMPLETE]
- Production build without deployment: [TEAM TO COMPLETE]
- Integration tests and local services: [TEAM TO COMPLETE]

## Shared API contract
- Authoritative repository or registry and owner: [TEAM TO COMPLETE]
- Immutable revision or published version: [TEAM TO COMPLETE]
- Approved local contract file or task attachment: [TEAM TO COMPLETE]
- Client generation or compatibility check command: [TEAM TO COMPLETE]
- Policy for breaking changes and release order: [TEAM TO COMPLETE]

## Review and completion
- Required CI checks and human reviewers: [TEAM TO COMPLETE]
- Areas requiring specialist review: [TEAM TO COMPLETE]
- Local configuration example with no secrets: [TEAM TO COMPLETE]
- Protected or generated paths: [TEAM TO COMPLETE]
